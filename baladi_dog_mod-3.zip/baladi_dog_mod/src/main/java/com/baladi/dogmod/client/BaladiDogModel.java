package com.baladi.dogmod.client;

import com.baladi.dogmod.BaladiDog;
import com.baladi.dogmod.BaladiDogMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Custom dog model (texture layout 128x64). */
public class BaladiDogModel extends EntityModel<BaladiDog> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(BaladiDogMod.MODID, "baladi_dog"), "main");

    private final ModelPart head, earL, earR, body, upperBody, collar;
    private final ModelPart rightHindLeg, leftHindLeg, rightFrontLeg, leftFrontLeg;
    private final ModelPart tail;

    public BaladiDogModel(ModelPart root) {
        this.head = root.getChild("head");
        this.earL = head.getChild("ear_l");
        this.earR = head.getChild("ear_r");
        this.body = root.getChild("body");
        this.upperBody = root.getChild("upper_body");
        this.collar = root.getChild("collar");
        this.rightHindLeg = root.getChild("right_hind_leg");
        this.leftHindLeg = root.getChild("left_hind_leg");
        this.rightFrontLeg = root.getChild("right_front_leg");
        this.leftFrontLeg = root.getChild("left_front_leg");
        this.tail = root.getChild("tail");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // head + short muzzle + floppy ears
        PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create(),
                PartPose.offset(-1.0F, 13.5F, -7.0F));
        head.addOrReplaceChild("real_head", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-2.0F, -3.0F, -2.5F, 6.0F, 6.0F, 5.0F)
                .texOffs(24, 0).addBox(-1.0F, -1.5F, -5.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        head.addOrReplaceChild("ear_l", CubeListBuilder.create()
                .texOffs(40, 0).addBox(0.0F, 0.0F, -1.5F, 1.0F, 4.0F, 3.0F),
                PartPose.offsetAndRotation(4.0F, -3.0F, 0.0F, 0.0F, 0.0F, -0.3F));
        head.addOrReplaceChild("ear_r", CubeListBuilder.create()
                .texOffs(48, 0).addBox(-1.0F, 0.0F, -1.5F, 1.0F, 4.0F, 3.0F),
                PartPose.offsetAndRotation(-2.0F, -3.0F, 0.0F, 0.0F, 0.0F, 0.3F));

        // chest / neck
        root.addOrReplaceChild("upper_body", CubeListBuilder.create()
                .texOffs(0, 12).addBox(-3.0F, -3.0F, -3.0F, 6.0F, 6.0F, 7.0F),
                PartPose.offsetAndRotation(0.0F, 14.0F, -3.0F, Mth.HALF_PI, 0.0F, 0.0F));
        // torso (length 10)
        root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(30, 12).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 10.0F, 6.0F),
                PartPose.offsetAndRotation(0.0F, 14.0F, 2.0F, Mth.HALF_PI, 0.0F, 0.0F));

        // collar ring (only has pixels in the collar texture)
        root.addOrReplaceChild("collar", CubeListBuilder.create()
                .texOffs(60, 0).addBox(-3.5F, -4.0F, -1.0F, 7.0F, 8.0F, 2.0F),
                PartPose.offset(0.0F, 13.5F, -5.0F));

        CubeListBuilder leg = CubeListBuilder.create().texOffs(0, 28).addBox(0.0F, 0.0F, -1.5F, 3.0F, 8.0F, 3.0F);
        CubeListBuilder legM = CubeListBuilder.create().mirror().texOffs(0, 28).addBox(-3.0F, 0.0F, -1.5F, 3.0F, 8.0F, 3.0F);
        root.addOrReplaceChild("right_hind_leg", leg, PartPose.offset(-3.5F, 16.0F, 8.0F));
        root.addOrReplaceChild("left_hind_leg", legM, PartPose.offset(3.5F, 16.0F, 8.0F));
        root.addOrReplaceChild("right_front_leg", leg, PartPose.offset(-3.5F, 16.0F, -4.0F));
        root.addOrReplaceChild("left_front_leg", legM, PartPose.offset(3.5F, 16.0F, -4.0F));

        PartDefinition tail = root.addOrReplaceChild("tail", CubeListBuilder.create(),
                PartPose.offsetAndRotation(0.0F, 12.0F, 9.5F, 1.5F, 0.0F, 0.0F));
        tail.addOrReplaceChild("real_tail", CubeListBuilder.create()
                .texOffs(14, 28).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 9.0F, 2.0F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 128, 64);
    }

    @Override
    public void setupAnim(BaladiDog e, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        head.xRot = headPitch * Mth.DEG_TO_RAD;
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;

        float flap = Mth.sin(limbSwing * 0.6F) * 0.18F * limbSwingAmount;
        earL.zRot = -0.3F - flap;
        earR.zRot = 0.3F + flap;

        float wag = e.isTame() ? Mth.cos(ageInTicks * 0.4F) * 0.25F : 0.0F;
        tail.yRot = wag;

        if (e.isInSittingPose()) {
            upperBody.setPos(0.0F, 16.0F, -3.0F);
            upperBody.xRot = 1.2566371F;
            body.setPos(0.0F, 18.0F, 0.0F);
            body.xRot = Mth.PI / 4.0F;
            collar.setPos(0.0F, 15.5F, -5.0F);
            collar.xRot = -0.31F;
            head.setPos(-1.0F, 15.5F, -7.0F);
            tail.setPos(0.0F, 21.0F, 6.5F);
            tail.xRot = 1.1F;
            rightHindLeg.setPos(-3.5F, 22.7F, 3.0F);
            leftHindLeg.setPos(3.5F, 22.7F, 3.0F);
            rightHindLeg.xRot = leftHindLeg.xRot = Mth.PI * 1.5F;
            rightFrontLeg.setPos(-3.5F, 17.0F, -4.0F);
            leftFrontLeg.setPos(3.5F, 17.0F, -4.0F);
            rightFrontLeg.xRot = leftFrontLeg.xRot = 5.811947F;
            return;
        }

        body.setPos(0.0F, 14.0F, 2.0F);
        upperBody.setPos(0.0F, 14.0F, -3.0F);
        collar.setPos(0.0F, 13.5F, -5.0F);
        collar.xRot = 0.0F;
        head.setPos(-1.0F, 13.5F, -7.0F);
        tail.setPos(0.0F, 12.0F, 9.5F);
        rightHindLeg.setPos(-3.5F, 16.0F, 8.0F);
        leftHindLeg.setPos(3.5F, 16.0F, 8.0F);
        rightFrontLeg.setPos(-3.5F, 16.0F, -4.0F);
        leftFrontLeg.setPos(3.5F, 16.0F, -4.0F);
        body.xRot = upperBody.xRot = Mth.HALF_PI;

        boolean running = e.isAggressive();
        // tail: relaxed = slightly down/back, aggressive = raised up/back (Z-rot positive = swings back)
        tail.xRot = running ? 2.2F : 1.5F;

        // natural gait: diagonal legs move together, the other pair in opposite phase
        float speed = running ? 0.8F : 0.6662F;
        float swing = (running ? 1.6F : 1.2F) * limbSwingAmount;
        float t = limbSwing * speed;
        rightHindLeg.xRot = Mth.cos(t) * swing;
        leftHindLeg.xRot = Mth.cos(t + Mth.PI) * swing;
        rightFrontLeg.xRot = Mth.cos(t + Mth.PI) * swing;
        leftFrontLeg.xRot = Mth.cos(t) * swing;
        if (running) {
            float bob = Mth.cos(t * 2.0F) * 0.35F * Math.min(limbSwingAmount, 1.0F);
            body.y += bob; upperBody.y += bob; head.y += bob; collar.y += bob; tail.y += bob;
            tail.xRot = 2.1F + Mth.sin(t) * 0.12F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, int color) {
        head.render(ps, vc, light, overlay, color);
        body.render(ps, vc, light, overlay, color);
        upperBody.render(ps, vc, light, overlay, color);
        collar.render(ps, vc, light, overlay, color);
        rightHindLeg.render(ps, vc, light, overlay, color);
        leftHindLeg.render(ps, vc, light, overlay, color);
        rightFrontLeg.render(ps, vc, light, overlay, color);
        leftFrontLeg.render(ps, vc, light, overlay, color);
        tail.render(ps, vc, light, overlay, color);
    }
}
